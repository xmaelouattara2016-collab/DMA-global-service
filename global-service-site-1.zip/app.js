(function () {
  "use strict";

  var COUNTRIES = ["Sénégal", "Côte d'Ivoire", "Mali", "Guinée"];
  var TAB_KEY = "gs-tab-v1", COST_KEY = "gs-lastcost-v1";
  var NB = " ";
  var $app = document.getElementById("app");
  var $toast = document.getElementById("toast");

  /* ---------- petites fonctions ---------- */
  var nf = new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 0 });
  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function num(v) { var x = parseFloat(v); return isFinite(x) ? x : 0; }
  function fmt(v) { return nf.format(Math.round(num(v))).replace(/[  ]/g, NB); }
  function money(v) { return fmt(v) + NB + "FCFA"; }
  function cls(v) { return v > 0 ? "pos" : v < 0 ? "neg" : ""; }
  function today() { var d = new Date(); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  function dateFr(d) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(d || ""); return m ? m[3] + "/" + m[2] : (d || ""); }
  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }

  /* ---------- calculs (fonctions pures) ---------- */
  function agg(data, ids) {
    var set = {}; ids.forEach(function (id) { set[id] = 1; });
    var r = { shipped: 0, cost: 0, sold: 0, revenue: 0, remitted: 0 };
    data.shipments.forEach(function (s) { if (set[s.agent_id]) { r.shipped += num(s.qty); r.cost += num(s.qty) * num(s.unit_cost); } });
    data.sales.forEach(function (s) { if (set[s.agent_id]) { r.sold += num(s.qty); r.revenue += num(s.amount); } });
    data.remittances.forEach(function (s) { if (set[s.agent_id]) r.remitted += num(s.amount); });
    r.avgCost = r.shipped > 0 ? r.cost / r.shipped : 0;
    r.remaining = r.shipped - r.sold;
    r.cogs = r.sold * r.avgCost;
    r.toRemit = r.revenue - r.remitted;
    return r;
  }
  function agentsOf(data, country) {
    return data.profiles.filter(function (p) { return p.role === "agent" && p.country === country; });
  }
  function countryStats(data, country) {
    var agents = agentsOf(data, country);
    var rows = agents.map(function (a) { var r = agg(data, [a.id]); r.agent = a; return r; });
    var t = { shipped: 0, sold: 0, remaining: 0, revenue: 0, remitted: 0, toRemit: 0, cogs: 0 };
    rows.forEach(function (r) { Object.keys(t).forEach(function (k) { t[k] += r[k]; }); });
    t.expenses = 0;
    data.expenses.forEach(function (e) { if (e.country === country) t.expenses += num(e.amount); });
    t.profit = t.revenue - t.cogs - t.expenses;
    return { rows: rows, total: t, agents: agents };
  }

  /* ---------- accès aux données ---------- */
  function makeApi() {
    var sb = window.supabase.createClient(window.GS_CONFIG.SUPABASE_URL, window.GS_CONFIG.SUPABASE_KEY);
    function ok(r) { if (r.error) throw r.error; return r.data; }
    function all(table, order, filter) {
      var out = [];
      function page(from) {
        var q = sb.from(table).select("*");
        if (filter) q = filter(q);
        if (order) q = q.order(order, { ascending: false });
        return q.range(from, from + 999).then(ok).then(function (rows) {
          out = out.concat(rows || []);
          return rows && rows.length === 1000 ? page(from + 1000) : out;
        });
      }
      return page(0);
    }
    return {
      session: function () { return sb.auth.getSession().then(function (r) { return r.data.session; }); },
      onAuth: function (cb) { sb.auth.onAuthStateChange(function (ev, s) { cb(s); }); },
      signIn: function (e, p) { return sb.auth.signInWithPassword({ email: e, password: p }).then(function (r) { if (r.error) throw r.error; }); },
      signUp: function (n, e, p) { return sb.auth.signUp({ email: e, password: p, options: { data: { name: n } } }).then(function (r) { if (r.error) throw r.error; return r.data; }); },
      signOut: function () { return sb.auth.signOut(); },
      profile: function (id) { return sb.from("profiles").select("*").eq("id", id).maybeSingle().then(ok); },
      loadOwner: function () {
        return Promise.all([all("profiles", "created_at"), all("shipments", "ship_date"), all("sales", "sale_date"), all("remittances", "paid_date"), all("expenses", "exp_date")])
          .then(function (a) { return { profiles: a[0], shipments: a[1], sales: a[2], remittances: a[3], expenses: a[4] }; });
      },
      loadAgent: function () {
        return Promise.all([all("my_shipments", "ship_date"), all("sales", "sale_date"), all("remittances", "paid_date")])
          .then(function (a) { return { profiles: [], shipments: a[0], sales: a[1], remittances: a[2], expenses: [] }; });
      },
      insert: function (table, row) { return sb.from(table).insert(row).then(ok); },
      remove: function (table, id) { return sb.from(table).delete().eq("id", id).then(ok); },
      updateProfile: function (id, patch) { return sb.from("profiles").update(patch).eq("id", id).then(ok); },
      subscribe: function (cb) {
        try { sb.channel("gs-live").on("postgres_changes", { event: "*", schema: "public" }, cb).subscribe(); } catch (e) {}
      }
    };
  }
  var api = window.__API__ || null;

  /* ---------- état ---------- */
  var S = { session: null, profile: null, data: null, tab: lsGet(TAB_KEY) || "total", authMode: "login", authMsg: "", authOk: "", authEmail: "", authName: "", busy: false, loading: true, updated: null, armed: null, loadError: "" };
  var armTimer = null, pollTimer = null, refreshTimer = null, pendingRender = false, liveOn = false;

  function toast(text, bad) {
    $toast.textContent = text; $toast.className = "toast show" + (bad ? " bad" : "");
    clearTimeout(toast.t); toast.t = setTimeout(function () { $toast.className = "toast"; }, 3200);
  }
  function errText(e) {
    var m = (e && (e.message || e.error_description)) || String(e || "");
    if (/Invalid login/i.test(m)) return "Email ou mot de passe incorrect.";
    if (/Email not confirmed/i.test(m)) return "Email non confirmé. Demande au propriétaire de désactiver la confirmation d'email, ou ouvre le lien reçu par email.";
    if (/already registered|already been registered/i.test(m)) return "Ce compte existe déjà. Connecte-toi.";
    if (/at least 6|Password should/i.test(m)) return "Mot de passe : 6 caractères minimum.";
    if (/valid email|invalid format/i.test(m)) return "Adresse email non valide.";
    if (/rate limit/i.test(m)) return "Trop de tentatives. Réessaie dans quelques minutes.";
    if (/Failed to fetch|NetworkError|network/i.test(m)) return "Pas de connexion internet.";
    return m;
  }

  /* ---------- rendu ---------- */
  function statTile(label, value, extra, klass) {
    return '<div class="stat-tile"><div class="eyebrow">' + label + '</div><div class="stat ' + (klass || "") + '">' + value + '</div>' + (extra ? '<div class="hint">' + extra + "</div>" : "") + "</div>";
  }
  function header() {
    var p = S.profile;
    var who = p ? esc(p.name || p.email) + " · " + (p.role === "owner" ? "Propriétaire" : p.role === "agent" ? "Agent " + esc(p.country || "") : "En attente") : "";
    return '<header class="top"><div class="brand"><img class="logo" src="logo.png" alt="DMA Global Services" width="44" height="44"><div><div class="eyebrow">Global Service</div><h1>' + (p && p.role === "owner" ? "Suivi des agents" : "Mes ventes") + '</h1></div></div>' +
      '<div class="who"><span class="small muted">' + who + '</span><div class="lotbar"><button type="button" data-act="refresh">Actualiser</button><button type="button" class="ghost" data-act="logout">Déconnexion</button></div>' +
      (S.updated ? '<span class="hint">Mis à jour à ' + S.updated + "</span>" : "") + "</div></header>";
  }

  function renderAuth() {
    var login = S.authMode === "login";
    return '<main class="narrow"><div class="brand"><img class="logo" src="logo.png" alt="DMA Global Services" width="44" height="44"><div><div class="eyebrow">Global Service</div><h1>' + (login ? "Connexion" : "Créer un compte") + '</h1></div></div>' +
      '<form class="panel" data-form="auth" novalidate>' +
      (login ? "" : '<div class="field"><label for="a-name">Ton nom</label><input id="a-name" name="name" type="text" autocomplete="name" value="' + esc(S.authName) + '" required></div>') +
      '<div class="field"><label for="a-email">Email</label><input id="a-email" name="email" type="email" autocomplete="email" inputmode="email" value="' + esc(S.authEmail) + '" required></div>' +
      '<div class="field"><label for="a-pw">Mot de passe</label><input id="a-pw" name="password" type="password" autocomplete="' + (login ? "current-password" : "new-password") + '" required></div>' +
      (S.authMsg ? '<div class="msg bad" role="alert">' + esc(S.authMsg) + "</div>" : "") +
      (S.authOk ? '<div class="msg" role="status">' + esc(S.authOk) + "</div>" : "") +
      '<button class="primary" type="submit"' + (S.busy ? " disabled" : "") + ">" + (login ? "Se connecter" : "Créer mon compte") + "</button>" +
      '<button type="button" class="ghost" data-act="authmode">' + (login ? "Je n'ai pas de compte" : "J'ai déjà un compte") + "</button>" +
      (login ? "" : '<div class="hint">Après la création, le propriétaire doit valider ton compte avant que tu puisses enregistrer des ventes.</div>') +
      "</form></main>";
  }

  function renderPending() {
    return '<main class="narrow">' + header() + '<section class="panel"><h2>Compte en attente</h2><p class="muted" style="margin:0">Ton compte est créé. Le propriétaire doit maintenant le valider et t\'attribuer ton pays. Reviens dans un moment, la page se met à jour toute seule.</p></section></main>';
  }

  function delBtn(table, id, label) {
    var key = table + ":" + id, armed = S.armed === key;
    return '<button type="button" class="mini danger' + (armed ? " armed" : "") + '" data-act="del" data-table="' + table + '" data-id="' + esc(id) + '" aria-label="Supprimer ' + esc(label || "") + '">' + (armed ? "Confirmer" : "Retirer") + "</button>";
  }
  function tableWrap(head, body, foot, min) {
    return '<div class="tablewrap"><table style="min-width:' + (min === undefined ? 480 : min) + 'px"><thead><tr>' + head + "</tr></thead><tbody>" + body + "</tbody>" + (foot ? "<tfoot>" + foot + "</tfoot>" : "") + "</table></div>";
  }
  function mini(label, value, klass) { return '<div><div class="eyebrow">' + label + '</div><div class="stat ' + (klass || "") + '">' + value + "</div></div>"; }
  function emptyRow(cols, text) { return '<tr><td colspan="' + cols + '" class="emptycell">' + text + "</td></tr>"; }

  /* ----- vue agent ----- */
  function renderAgent() {
    var d = S.data || { shipments: [], sales: [], remittances: [] };
    var me = S.profile.id;
    var a = agg(d, [me]);
    a.avgCost = 0;
    var recent = d.sales.slice(0, 40);
    var now = Date.now();
    var rows = recent.map(function (s) {
      var canDel = now - new Date(s.created_at).getTime() < 86400000;
      return "<tr><td>" + dateFr(s.sale_date) + "</td><td>" + fmt(s.qty) + "</td><td>" + fmt(s.amount) + '</td><td class="txt">' + esc(s.place || "") + "</td><td>" + (canDel ? delBtn("sales", s.id, "cette vente") : "") + "</td></tr>";
    }).join("");
    var ship = d.shipments.slice(0, 15).map(function (s) { return "<tr><td>" + dateFr(s.ship_date) + "</td><td>" + fmt(s.qty) + "</td></tr>"; }).join("");
    var rem = d.remittances.slice(0, 15).map(function (s) { return "<tr><td>" + dateFr(s.paid_date) + "</td><td>" + fmt(s.amount) + "</td></tr>"; }).join("");
    return '<main>' + header() +
      '<section class="panel result"><div class="bigline"><span class="eyebrow">Sachets restants</span><span class="big ' + (a.remaining < 0 ? "neg" : "") + '">' + fmt(a.remaining) + '</span><span class="muted small">' + fmt(a.shipped) + " reçus · " + fmt(a.sold) + " vendus</span></div>" +
      '<div class="pair">' + statTile("Total à me verser", money(a.revenue), "Somme de tes ventes") + statTile("Déjà versé", money(a.remitted)) + statTile("Reste à verser", money(a.toRemit), "", a.toRemit > 0 ? "warn" : "pos") + "</div></section>" +
      '<section class="panel"><h2>Enregistrer une vente</h2><form data-form="sale" class="fields" novalidate>' +
      '<div class="field"><label for="s-date">Date</label><input id="s-date" name="date" type="date" value="' + today() + '" required></div>' +
      '<div class="field"><label for="s-qty">Sachets vendus</label><input id="s-qty" name="qty" type="number" inputmode="numeric" min="1" step="1" required></div>' +
      '<div class="field"><label for="s-amount">Montant à me verser (FCFA)</label><input id="s-amount" name="amount" type="number" inputmode="decimal" min="0" step="any" required></div>' +
      '<div class="field"><label for="s-place">Client et ville (facultatif)</label><input id="s-place" name="place" type="text" autocomplete="off"></div>' +
      '<div class="field wide"><button class="primary" type="submit"' + (S.busy ? " disabled" : "") + ">Enregistrer la vente</button></div></form></section>" +
      '<section class="panel"><h2>Mes dernières ventes</h2><div class="hint">Tu peux retirer une vente saisie par erreur pendant 24 heures.</div>' +
      tableWrap("<th>Jour</th><th>Sachets</th><th>Montant</th><th>Client</th><th></th>", rows || emptyRow(5, "Aucune vente pour le moment."), "", 440) + "</section>" +
      '<section class="panel"><h2>Stock reçu et sommes versées</h2><div class="pair2"><div>' +
      tableWrap("<th>Jour</th><th>Sachets reçus</th>", ship || emptyRow(2, "Aucun envoi."), "", 0) + "</div><div>" +
      tableWrap("<th>Jour</th><th>Versé (FCFA)</th>", rem || emptyRow(2, "Aucun versement."), "", 0) + "</div></div></section></main>";
  }

  /* ----- vue propriétaire ----- */
  function ownerTabs(d) {
    var present = COUNTRIES.filter(function (c) {
      return d.profiles.some(function (p) { return p.role === "agent" && p.country === c; }) || d.expenses.some(function (e) { return e.country === c; });
    });
    var pending = d.profiles.filter(function (p) { return p.role === "pending"; }).length;
    return { list: ["total"].concat(present, ["agents"]), pending: pending };
  }
  function tabBar(t) {
    return '<nav class="tabs" role="tablist" aria-label="Pays">' + t.list.map(function (k) {
      var label = k === "total" ? "Total" : k === "agents" ? "Agents" : k;
      var badge = k === "agents" && t.pending ? ' <span class="badge">' + t.pending + "</span>" : "";
      return '<button type="button" role="tab" aria-selected="' + (S.tab === k) + '" class="tab' + (S.tab === k ? " on" : "") + '" data-act="tab" data-tab="' + esc(k) + '">' + esc(label) + badge + "</button>";
    }).join("") + "</nav>";
  }

  function ownerTotal(d) {
    var present = ownerTabs(d).list.filter(function (k) { return k !== "total" && k !== "agents"; });
    var T = { shipped: 0, sold: 0, remaining: 0, revenue: 0, remitted: 0, toRemit: 0, expenses: 0, profit: 0 };
    var cards = present.map(function (c) {
      var st = countryStats(d, c).total;
      Object.keys(T).forEach(function (k) { T[k] += st[k]; });
      return '<div class="agentcard"><div class="agname"><button type="button" class="link" data-act="tab" data-tab="' + esc(c) + '">' + esc(c) + "</button></div><div class=\"mini-grid\">" +
        mini("Envoyés", fmt(st.shipped)) + mini("Vendus", fmt(st.sold)) + mini("Restants", fmt(st.remaining)) + mini("Ventes", fmt(st.revenue)) + mini("Versé", fmt(st.remitted)) + mini("À recevoir", fmt(st.toRemit), st.toRemit > 0 ? "warn" : "") + mini("Dépenses", fmt(st.expenses)) + mini("Bénéfice", fmt(st.profit), cls(st.profit)) + "</div></div>";
    }).join("");
    return '<section class="panel result"><div class="bigline"><span class="eyebrow">Bénéfice net, tous pays</span><span class="big ' + cls(T.profit) + '">' + money(T.profit) + '</span><span class="muted small">Ventes − coût des sachets vendus − dépenses de campagnes</span></div>' +
      '<div class="pair">' + statTile("Chiffre d\'affaires", money(T.revenue), fmt(T.sold) + " sachets vendus") + statTile("Reste à recevoir des agents", money(T.toRemit), "Déjà reçu : " + money(T.remitted), T.toRemit > 0 ? "warn" : "pos") + statTile("Stock chez les agents", fmt(T.remaining) + " sachets", fmt(T.shipped) + " envoyés") + statTile("Dépenses de campagnes", money(T.expenses)) + "</div></section>" +
      '<section class="panel"><h2>Par pays</h2><div class="hint">Montants en FCFA. Touche un pays pour voir le détail.</div>' +
      (cards ? '<div class="rows">' + cards + "</div>" : '<div class="muted small">Aucun agent validé pour le moment. Va dans l\'onglet Agents.</div>') + "</section>";
  }

  function agentOptions(agents) {
    return agents.map(function (a) { return '<option value="' + esc(a.id) + '">' + esc(a.name || a.email) + "</option>"; }).join("");
  }
  function ownerCountry(d, country) {
    var st = countryStats(d, country), t = st.total, agents = st.agents;
    var nameOf = {}; d.profiles.forEach(function (p) { nameOf[p.id] = p.name || p.email; });
    var ids = {}; agents.forEach(function (a) { ids[a.id] = 1; });

    var agentCards = st.rows.map(function (r) {
      return '<div class="agentcard"><div class="agname">' + esc(r.agent.name || r.agent.email) + '</div><div class="mini-grid">' +
        mini("Envoyés", fmt(r.shipped)) + mini("Vendus", fmt(r.sold)) + mini("Restants", fmt(r.remaining), r.remaining < 0 ? "neg" : "") + mini("Ventes", fmt(r.revenue)) + mini("Versé", fmt(r.remitted)) + mini("À recevoir", fmt(r.toRemit), r.toRemit > 0 ? "warn" : "") + "</div></div>";
    }).join("");

    var cSales = d.sales.filter(function (s) { return ids[s.agent_id]; });
    var byDay = {};
    cSales.forEach(function (s) { var k = s.sale_date; (byDay[k] = byDay[k] || { q: 0, a: 0 }); byDay[k].q += num(s.qty); byDay[k].a += num(s.amount); });
    var dayRows = Object.keys(byDay).sort().reverse().slice(0, 30).map(function (k) { return "<tr><td>" + dateFr(k) + "</td><td>" + fmt(byDay[k].q) + "</td><td>" + fmt(byDay[k].a) + "</td></tr>"; }).join("");

    var saleRows = cSales.slice(0, 25).map(function (s) {
      return "<tr><td>" + dateFr(s.sale_date) + '</td><td class="txt">' + esc(nameOf[s.agent_id] || "") + "</td><td>" + fmt(s.qty) + "</td><td>" + fmt(s.amount) + '</td><td class="txt">' + esc(s.place || "") + "</td><td>" + delBtn("sales", s.id, "cette vente") + "</td></tr>";
    }).join("");
    var cShip = d.shipments.filter(function (s) { return ids[s.agent_id]; }).slice(0, 20).map(function (s) {
      return "<tr><td>" + dateFr(s.ship_date) + '</td><td class="txt">' + esc(nameOf[s.agent_id] || "") + "</td><td>" + fmt(s.qty) + "</td><td>" + fmt(s.unit_cost) + "</td><td>" + delBtn("shipments", s.id, "cet envoi") + "</td></tr>";
    }).join("");
    var cRem = d.remittances.filter(function (s) { return ids[s.agent_id]; }).slice(0, 20).map(function (s) {
      return "<tr><td>" + dateFr(s.paid_date) + '</td><td class="txt">' + esc(nameOf[s.agent_id] || "") + "</td><td>" + fmt(s.amount) + "</td><td>" + delBtn("remittances", s.id, "ce versement") + "</td></tr>";
    }).join("");
    var cExp = d.expenses.filter(function (e) { return e.country === country; }).slice(0, 20).map(function (e) {
      return "<tr><td>" + dateFr(e.exp_date) + '</td><td class="txt">' + esc(e.label) + "</td><td>" + fmt(e.amount) + "</td><td>" + delBtn("expenses", e.id, "cette dépense") + "</td></tr>";
    }).join("");

    var lastCost = lsGet(COST_KEY) || "";
    var forms = agents.length ? (
      '<details class="panel fold"><summary>Envoyer du stock à un agent</summary><form data-form="shipment" class="fields" novalidate>' +
      '<div class="field"><label for="f1-agent">Agent</label><select id="f1-agent" name="agent_id">' + agentOptions(agents) + "</select></div>" +
      '<div class="field"><label for="f1-date">Date</label><input id="f1-date" name="date" type="date" value="' + today() + '"></div>' +
      '<div class="field"><label for="f1-qty">Sachets envoyés</label><input id="f1-qty" name="qty" type="number" inputmode="numeric" min="1" step="1" required></div>' +
      '<div class="field"><label for="f1-cost">Coût de revient par sachet (FCFA)</label><input id="f1-cost" name="unit_cost" type="number" inputmode="decimal" min="0" step="any" value="' + esc(lastCost) + '" required><span class="hint">Achat plus transport, divisé par le nombre de sachets. L\'agent ne le voit pas.</span></div>' +
      '<div class="field wide"><button class="primary" type="submit">Enregistrer l\'envoi</button></div></form></details>' +
      '<details class="panel fold"><summary>Enregistrer un versement reçu</summary><form data-form="remittance" class="fields" novalidate>' +
      '<div class="field"><label for="f2-agent">Agent</label><select id="f2-agent" name="agent_id">' + agentOptions(agents) + "</select></div>" +
      '<div class="field"><label for="f2-date">Date</label><input id="f2-date" name="date" type="date" value="' + today() + '"></div>' +
      '<div class="field wide"><label for="f2-amount">Montant reçu (FCFA)</label><input id="f2-amount" name="amount" type="number" inputmode="decimal" min="1" step="any" required></div>' +
      '<div class="field wide"><button class="primary" type="submit">Enregistrer le versement</button></div></form></details>'
    ) : '<section class="panel"><div class="muted">Aucun agent dans ce pays pour le moment.</div></section>';
    var expForm = '<details class="panel fold"><summary>Ajouter une dépense de campagne</summary><form data-form="expense" class="fields" novalidate><input type="hidden" name="country" value="' + esc(country) + '">' +
      '<div class="field"><label for="f3-label">Description</label><input id="f3-label" name="label" type="text" value="TikTok" required></div>' +
      '<div class="field"><label for="f3-date">Date</label><input id="f3-date" name="date" type="date" value="' + today() + '"></div>' +
      '<div class="field wide"><label for="f3-amount">Montant dépensé (FCFA)</label><input id="f3-amount" name="amount" type="number" inputmode="decimal" min="1" step="any" required></div>' +
      '<div class="field wide"><button class="primary" type="submit">Enregistrer la dépense</button></div></form></details>';

    return '<section class="panel result"><div class="bigline"><span class="eyebrow">Bénéfice net · ' + esc(country) + '</span><span class="big ' + cls(t.profit) + '">' + money(t.profit) + '</span><span class="muted small">Ventes − coût des sachets vendus − dépenses de campagnes</span></div>' +
      '<div class="pair">' + statTile("Chiffre d\'affaires", money(t.revenue), fmt(t.sold) + " sachets vendus") + statTile("Reste à recevoir", money(t.toRemit), "Déjà reçu : " + money(t.remitted), t.toRemit > 0 ? "warn" : "pos") + statTile("Stock restant chez l\'agent", fmt(t.remaining) + " sachets", fmt(t.shipped) + " envoyés") + statTile("Dépenses de campagnes", money(t.expenses), "Coût des sachets vendus : " + money(t.cogs)) + "</div></section>" +
      '<section class="panel"><h2>Agents</h2>' + (agentCards ? '<div class="rows">' + agentCards + "</div>" : '<div class="muted small">Aucun agent.</div>') + "</section>" +
      forms + expForm +
      '<section class="panel"><h2>Ventes par jour</h2>' + tableWrap("<th>Jour</th><th>Sachets</th><th>Montant (FCFA)</th>", dayRows || emptyRow(3, "Aucune vente."), "", 0) + "</section>" +
      '<section class="panel"><h2>Dernières ventes saisies</h2>' + tableWrap("<th>Jour</th><th>Agent</th><th>Sachets</th><th>Montant</th><th>Client</th><th></th>", saleRows || emptyRow(6, "Aucune vente."), "", 560) + "</section>" +
      '<section class="panel"><h2>Envois, versements et dépenses</h2><h3>Stock envoyé</h3>' + tableWrap("<th>Jour</th><th>Agent</th><th>Sachets</th><th>Coût/sachet</th><th></th>", cShip || emptyRow(5, "Aucun envoi."), "", 480) +
      "<h3>Versements reçus</h3>" + tableWrap("<th>Jour</th><th>Agent</th><th>Montant</th><th></th>", cRem || emptyRow(4, "Aucun versement."), "", 420) +
      "<h3>Dépenses de campagnes</h3>" + tableWrap("<th>Jour</th><th>Description</th><th>Montant</th><th></th>", cExp || emptyRow(4, "Aucune dépense."), "", 420) + "</section>";
  }

  function ownerAgents(d) {
    var pend = d.profiles.filter(function (p) { return p.role === "pending"; });
    var act = d.profiles.filter(function (p) { return p.role === "agent"; });
    function countrySel(id, cur) {
      return '<select data-country="' + esc(id) + '" aria-label="Pays">' + (cur ? "" : '<option value="">Choisir le pays</option>') + COUNTRIES.map(function (c) { return '<option value="' + esc(c) + '"' + (c === cur ? " selected" : "") + ">" + esc(c) + "</option>"; }).join("") + "</select>";
    }
    var pendHtml = pend.length ? pend.map(function (p) {
      return '<div class="row"><div class="rowtxt"><strong>' + esc(p.name || "") + '</strong><div class="hint">' + esc(p.email || "") + "</div></div>" + countrySel(p.id, "") + '<button type="button" class="primary mini2" data-act="approve" data-id="' + esc(p.id) + '">Valider comme agent</button>' + delBtn("profiles", p.id, "ce compte") + "</div>";
    }).join("") : '<div class="muted small">Aucun compte en attente.</div>';
    var actHtml = act.length ? act.map(function (p) {
      return '<div class="row"><div class="rowtxt"><strong>' + esc(p.name || "") + '</strong><div class="hint">' + esc(p.email || "") + "</div></div>" + countrySel(p.id, p.country) + '<button type="button" class="mini2" data-act="setcountry" data-id="' + esc(p.id) + '">Changer le pays</button><button type="button" class="mini danger" data-act="deactivate" data-id="' + esc(p.id) + '">Désactiver</button></div>';
    }).join("") : '<div class="muted small">Aucun agent validé.</div>';
    return '<section class="panel"><h2>Comptes en attente</h2><div class="hint">Envoie l\'adresse de l\'application à ton agent. Il crée son compte, puis il apparaît ici. Choisis son pays et valide.</div><div class="rows">' + pendHtml + "</div></section>" +
      '<section class="panel"><h2>Agents validés</h2><div class="rows">' + actHtml + "</div></section>";
  }

  function renderOwner() {
    var d = S.data || { profiles: [], shipments: [], sales: [], remittances: [], expenses: [] };
    var t = ownerTabs(d);
    if (t.list.indexOf(S.tab) < 0) S.tab = "total";
    var body = S.tab === "total" ? ownerTotal(d) : S.tab === "agents" ? ownerAgents(d) : ownerCountry(d, S.tab);
    return "<main>" + header() + tabBar(t) + body + "</main>";
  }

  function render(force) {
    var ae = document.activeElement;
    if (!force && ae && $app.contains(ae) && /^(INPUT|SELECT|TEXTAREA)$/.test(ae.tagName)) { pendingRender = true; return; }
    pendingRender = false;
    var open = {};
    Array.prototype.forEach.call($app.querySelectorAll("details"), function (el, i) { if (el.open) open[el.querySelector("summary").textContent] = 1; });
    var y = window.pageYOffset;
    var html;
    if (!window.__API__ && window.GS_CONFIG && /REMPLACER/.test(window.GS_CONFIG.SUPABASE_URL + window.GS_CONFIG.SUPABASE_KEY)) {
      html = '<main class="narrow"><section class="panel"><h2>Configuration manquante</h2><p class="muted" style="margin:0">L\'adresse et la clé de la base de données ne sont pas encore renseignées dans le fichier config.js.</p></section></main>';
    } else if (S.loading) html = '<main class="narrow"><div class="muted">Chargement…</div></main>';
    else if (!S.session) html = renderAuth();
    else if (!S.profile) html = '<main class="narrow">' + header() + '<section class="panel"><div class="muted">' + (S.loadError ? esc(S.loadError) : "Chargement du profil…") + "</div></section></main>";
    else if (S.profile.role === "owner") html = renderOwner();
    else if (S.profile.role === "agent") html = renderAgent();
    else html = renderPending();
    $app.innerHTML = html;
    Array.prototype.forEach.call($app.querySelectorAll("details"), function (el) { if (open[el.querySelector("summary").textContent]) el.open = true; });
    window.scrollTo(0, y);
  }

  /* ---------- chargement ---------- */
  function loadProfile() {
    if (!S.session) { S.profile = null; return Promise.resolve(); }
    return api.profile(S.session.user.id).then(function (p) { S.profile = p; S.loadError = ""; }, function (e) { S.loadError = errText(e); });
  }
  function refresh(force) {
    if (!S.session) return Promise.resolve();
    return loadProfile().then(function () {
      if (!S.profile || S.profile.role === "pending") return null;
      return (S.profile.role === "owner" ? api.loadOwner() : api.loadAgent()).then(function (d) { S.data = d; S.loadError = ""; }, function (e) { S.loadError = errText(e); if (force) toast(errText(e), true); });
    }).then(function () {
      var n = new Date(); S.updated = String(n.getHours()).padStart(2, "0") + ":" + String(n.getMinutes()).padStart(2, "0");
      render(force);
      if (S.profile && !liveOn) { liveOn = true; api.subscribe(function () { clearTimeout(refreshTimer); refreshTimer = setTimeout(function () { refresh(false); }, 500); }); }
    });
  }
  function startSession(s) {
    S.session = s; S.profile = null; S.data = null; S.loading = false;
    clearInterval(pollTimer);
    if (!s) { render(true); return; }
    render(true);
    refresh(true);
    pollTimer = setInterval(function () { refresh(false); }, 30000);
  }

  /* ---------- actions ---------- */
  function armDelete(key) {
    S.armed = key; clearTimeout(armTimer);
    armTimer = setTimeout(function () { S.armed = null; render(false); }, 4000);
    render(true);
  }
  function run(promise, okText) {
    S.busy = true;
    return promise.then(function () { S.busy = false; if (okText) toast(okText); return refresh(true); }, function (e) { S.busy = false; toast(errText(e), true); render(true); });
  }

  $app.addEventListener("click", function (e) {
    var b = e.target.closest("[data-act]"); if (!b) return;
    var act = b.getAttribute("data-act"), id = b.getAttribute("data-id");
    if (act === "tab") { S.tab = b.getAttribute("data-tab"); lsSet(TAB_KEY, S.tab); render(true); window.scrollTo(0, 0); }
    else if (act === "refresh") { refresh(true).then(function () { toast("Mis à jour."); }); }
    else if (act === "logout") { api.signOut().then(function () { liveOn = false; startSession(null); }); }
    else if (act === "authmode") { S.authMode = S.authMode === "login" ? "signup" : "login"; S.authMsg = ""; S.authOk = ""; render(true); }
    else if (act === "del") {
      var key = b.getAttribute("data-table") + ":" + id;
      if (S.armed !== key) { armDelete(key); return; }
      clearTimeout(armTimer); S.armed = null;
      run(api.remove(b.getAttribute("data-table"), id), "Supprimé.");
    }
    else if (act === "approve" || act === "setcountry") {
      var sel = $app.querySelector('select[data-country="' + id + '"]');
      if (!sel || !sel.value) { toast("Choisis d'abord le pays.", true); return; }
      var patch = act === "approve" ? { role: "agent", country: sel.value } : { country: sel.value };
      run(api.updateProfile(id, patch), act === "approve" ? "Agent validé." : "Pays modifié.");
    }
    else if (act === "deactivate") {
      var key2 = "deact:" + id;
      if (S.armed !== key2) { armDelete(key2); b.textContent = "Confirmer"; return; }
      clearTimeout(armTimer); S.armed = null;
      run(api.updateProfile(id, { role: "pending" }), "Agent désactivé.");
    }
  });

  $app.addEventListener("submit", function (e) {
    var f = e.target.closest("form[data-form]"); if (!f) return;
    e.preventDefault();
    var kind = f.getAttribute("data-form"), fd = new FormData(f);
    function v(k) { return String(fd.get(k) == null ? "" : fd.get(k)).trim(); }
    if (S.busy) return;
    if (kind === "auth") {
      var email = v("email"), pw = v("password"), name = v("name");
      S.authMsg = ""; S.authOk = ""; S.authEmail = email; S.authName = name;
      if (!email || !pw || (S.authMode === "signup" && !name)) { S.authMsg = "Remplis tous les champs."; render(true); return; }
      S.busy = true; render(true);
      var p = S.authMode === "login" ? api.signIn(email, pw) : api.signUp(name, email, pw).then(function (r) { if (!r || !r.session) S.authOk = "Compte créé. Vérifie ton email pour confirmer, puis connecte-toi."; });
      p.then(function () { S.busy = false; if (S.authMode === "signup" && S.authOk) S.authMode = "login"; render(true); }, function (err) { S.busy = false; S.authMsg = errText(err); render(true); });
      return;
    }
    if (kind === "sale") {
      var q = num(v("qty")), a = num(v("amount"));
      if (q < 1 || !isFinite(a) || v("amount") === "") { toast("Indique le nombre de sachets et le montant.", true); return; }
      run(api.insert("sales", { agent_id: S.session.user.id, sale_date: v("date") || today(), qty: Math.round(q), amount: a, place: v("place") || null }), "Vente enregistrée.");
    } else if (kind === "shipment") {
      var sq = num(v("qty")), sc = num(v("unit_cost"));
      if (!v("agent_id") || sq < 1 || v("unit_cost") === "") { toast("Choisis l'agent, le nombre de sachets et le coût.", true); return; }
      lsSet(COST_KEY, v("unit_cost"));
      run(api.insert("shipments", { agent_id: v("agent_id"), ship_date: v("date") || today(), qty: Math.round(sq), unit_cost: sc }), "Envoi enregistré.");
    } else if (kind === "remittance") {
      var ra = num(v("amount"));
      if (!v("agent_id") || ra <= 0) { toast("Choisis l'agent et le montant.", true); return; }
      run(api.insert("remittances", { agent_id: v("agent_id"), paid_date: v("date") || today(), amount: ra }), "Versement enregistré.");
    } else if (kind === "expense") {
      var ea = num(v("amount"));
      if (ea <= 0 || !v("label")) { toast("Indique la description et le montant.", true); return; }
      run(api.insert("expenses", { country: v("country"), exp_date: v("date") || today(), label: v("label"), amount: ea }), "Dépense enregistrée.");
    }
  });

  $app.addEventListener("focusout", function () {
    setTimeout(function () { if (pendingRender) render(false); }, 150);
  });
  document.addEventListener("visibilitychange", function () { if (!document.hidden && S.session) refresh(false); });

  /* ---------- démarrage ---------- */
  window.__GS = { agg: agg, countryStats: countryStats };
  if (window.GS_CONFIG && /REMPLACER/.test(window.GS_CONFIG.SUPABASE_URL + window.GS_CONFIG.SUPABASE_KEY) && !window.__API__) { S.loading = false; render(true); return; }
  if (!api) {
    if (!window.supabase) { S.loading = false; $app.innerHTML = '<main class="narrow"><section class="panel"><h2>Connexion impossible</h2><p class="muted" style="margin:0">Impossible de charger le service. Vérifie ta connexion internet et recharge la page.</p></section></main>'; return; }
    api = makeApi();
  }
  api.onAuth(function (s) { if ((s && s.user && S.session && S.session.user.id === s.user.id) || (!s && !S.session)) { S.session = s; return; } startSession(s); });
  api.session().then(function (s) { if (!S.session) startSession(s); else S.loading = false; }, function () { startSession(null); });
})();
