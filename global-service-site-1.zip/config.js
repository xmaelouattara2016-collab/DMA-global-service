window.GS_CONFIG = {
  SUPABASE_URL: "https://tionnxwatiikcscbrcyc.supabase.co",
  SUPABASE_KEY: "sb_publishable_j1DrU3w_m-iR9nzRUX8DzA_uUstGqaf"
};
